from UI import GymBookingUI

if __name__ == "__main__":
    app = GymBookingUI()
    app.run()
